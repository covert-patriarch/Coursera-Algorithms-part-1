/* *****************************************************************************
 *  Name:              Alan Turing
 *  Coursera User ID:  123456
 *  Last modified:     1/1/2019
 **************************************************************************** */

import edu.princeton.cs.algs4.StdOut;

import java.util.Arrays;

public class FastCollinearPoints {
    private final Point[] ps;
    private int l, nlines, st;
    private final LineSegment[] list;
    private double[] temp1;

    private class Pointws implements Comparable<Pointws> {
        private Point cp;
        private double slope;

        public Pointws(Point mp, Point lp) {
            cp = lp;
            slope = mp.slopeTo(lp);
        }

        public int compareTo(Pointws that) {
            if (this.slope == that.slope) {
                return this.cp.compareTo(that.cp);
            }
            else if (this.slope < that.slope) return -1;
            else return 1;
        }

        public double slope() {
            return slope;
        }

        public Point cp() {
            return cp;
        }

    }

    public FastCollinearPoints(Point[] points) {
        boolean p = true;
        if (points == null) {
            p = false;
        }
        l = points.length;
        nlines = 0;
        st = 0;

        for (int i = 0; i < l; i++) {
            if (points[i] == null) {
                p = false;
                break;
            }
        }

        Arrays.sort(points);
        for (int i = 1; i < l; i++) {
            String s1 = points[i - 1].toString();
            String s2 = points[i].toString();
            if (s1.equals(s2)) {
                p = false;
                break;
            }
        }
        if (!p) {
            throw new IllegalArgumentException();
        }
        //ps = points;
       /* for (int i = 0; i < ps.length; i++) {
            StdOut.println(ps[i].toString());
        }*/
        ps = new Point[l];
        for (int i = 0; i < l; i++) ps[i] = points[i];
    }

    // private Point test2 = new Point(0, 0);

    private int bsearch(double x, int len) {
        int l = 0, r = len - 1;
        while (l <= r) {
            int m = l + (r - l) / 2;
            if (temp1[m] == x) {
                return m;
            }

            if (temp1[m] < x) l = m + 1;
            else r = m - 1;

        }
        return -1;


    }

    private void lines(int first) {
        double[] temp = new double[l - first - 1];
        temp1 = new double[first];
        for (int i = first + 1; i < l; i++) {
            temp[i - first - 1] = ps[first].slopeTo(ps[i]);
        }
        for (int i = 0; i < first; i++) {
            temp1[i] = ps[first].slopeTo(ps[i]);
        }
        Arrays.sort(temp);
        Arrays.sort(temp1);

        int count = 1, back = 0;
        for (int i = 1; i < l - first - 1; i++) {
            // StdOut.println(first + " " + temp[i] + " " + temp[i - 1]);
            int ind = bsearch(temp[i], first);
            if (ind != -1) continue;
            if (temp[i] == (temp[i - 1])) {
                count++;
            }
            else {
                if (count >= 3) {

                    nlines++;
                }
                count = 1;
            }
        }
        if (count >= 3) {

            nlines++;
        }

    }

    private void lineadder(int first) {

        Pointws[] temp = new Pointws[l - first - 1];
        temp1 = new double[first];
        for (int i = first + 1; i < l; i++) {
            temp[i - first - 1] = new Pointws(ps[first], ps[i]);
        }
        for (int i = 0; i < first; i++) {
            temp1[i] = ps[i].slopeTo(ps[first]);
        }
        Arrays.sort(temp);
        Arrays.sort(temp1);

        int count = 1, back = 0;
        for (int i = 1; i < l - first - 1; i++) {
            // binary search in temp array slopes
            int ind = bsearch(temp[i - 1].slope(), first);

            if (ind != -1) continue;

            if (temp[i].slope() == temp[i - 1].slope()) {
                count++;
            }
            else {
                if (count >= 3) {
                    list[st] = new LineSegment(ps[first], temp[i - 1].cp());
                    st++;
                    // StdOut.println("st " + st);
                }
                count = 1;
            }
        }

        if (count >= 3) {
            list[st] = new LineSegment(ps[first], temp[l - first - 2].cp());
            st++;
            // StdOut.println("st " + st);
        }
    }

    public int numberOfSegments() {

        for (int i = 0; i < l - 1; i++) {
            lines(i);
        }
        return nlines;
    }

    public LineSegment[] segments() {
        // StdOut.println(l);
        if (st != 0) return list;
        st = numberOfSegments();
        //StdOut.println(nlines);
        st = 0;
        list = new LineSegment[nlines];
        for (int i = 0; i < l - 1; i++) {
            lineadder(i);
        }
        //StdOut.println(st);
        return list;
    }

    public static void main(String[] args) {
        Point[] test = new Point[6];
        test[0] = new Point(7, 7);
        test[1] = new Point(5, 3);
        test[2] = new Point(2, 0);
        test[3] = new Point(4, 2);
        test[4] = new Point(5, 5);
        test[5] = new Point(6, 4);
        //test[5] = new Point(1, -1);


        FastCollinearPoints s = new FastCollinearPoints(test);
        LineSegment[] ls;
        ls = s.segments();
        for (int i = 0; i < ls.length; i++) {

            // StdOut.println(ls.length);
            StdOut.println(ls[i].toString());
        }
    }
}
