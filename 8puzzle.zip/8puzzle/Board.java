import edu.princeton.cs.algs4.Stack;
import edu.princeton.cs.algs4.StdOut;

import java.util.Arrays;

public class Board {
    private final int[][] btiles;
    private int rows;
    private int tot;
    private int i0, j0;
    private int manhattan, hamming;

    public Board(int[][] tiles) {
        rows = tiles.length;
        tot = rows * rows;
        btiles = new int[rows][rows];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < rows; j++) {
                btiles[i][j] = tiles[i][j];
                if (tiles[i][j] == 0) {
                    i0 = i;
                    j0 = j;
                }
            }
        }
        manhattan = manhattanexe();
        hamming = hammingexe();
    }


    public String toString() {
        String s = String.valueOf(rows) + "\n";
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < rows; j++) {
                s += " " + String.valueOf(btiles[i][j]);
            }
            s += "\n";
        }
        return s;
    }

    public int dimension() {
        return rows;
    }

    private int hammingexe() {
        int count = 0;
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < rows; j++) {
                if (btiles[i][j] != ((i * rows + j) % tot + 1) % tot && btiles[i][j] != 0) {
                    count++;
                }
            }
        }

        return count;
    }

    private int manhattanexe() {
        int distance = 0;
        int oi, oj;
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < rows; j++) {
                if (btiles[i][j] != ((i * rows + j) % tot + 1) % tot && btiles[i][j] != 0) {

                    oi = (btiles[i][j] - 1) / rows;
                    oj = (btiles[i][j] - 1) % rows;
                    distance += Math.abs(i - oi) + Math.abs(j - oj);
                }
            }

        }
        return distance;
    }

    public int hamming() {
        return hamming;
    }

    public int manhattan() {
        return manhattan;
    }

    public boolean isGoal() {
        return hamming() == 0;
    }

    public boolean equals(Object y) {
        if (y == this) return true;
        if (y == null) return false;
        if (y.getClass() != this.getClass()) return false;
        Board that = (Board) y;
        return Arrays.deepEquals(this.btiles, that.btiles);
    }

    private Board exchange(int oldi, int oldj, int newi, int newj) {
        int[][] temparr = new int[rows][rows];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < rows; j++) {
                temparr[i][j] = btiles[i][j];
            }
        }
        int temp = temparr[oldi][oldj];
        temparr[oldi][oldj] = temparr[newi][newj];
        temparr[newi][newj] = temp;
        Board exch = new Board(temparr);
        //StdOut.println(exch.toString());
        return exch;

    }

    public Iterable<Board> neighbors() {

        Stack<Board> neigh = new Stack<Board>();
        if (i0 != 0) {
            // upexchange is possible;
            neigh.push(exchange(i0, j0, i0 - 1, j0));
        }
        if (i0 != rows - 1) {
            // down exchange possible
            neigh.push(exchange(i0, j0, i0 + 1, j0));

        }
        if (j0 != 0) {
            // left exchange possible;
            neigh.push(exchange(i0, j0, i0, j0 - 1));

        }
        if (j0 != rows - 1) {
            // right exchange is possible;
            neigh.push(exchange(i0, j0, i0, j0 + 1));

        }
        return neigh;


    }

    public Board twin() {
        int i = 0, j = 0;
        if (i == i0) {
            return exchange(i + 1, j, i + 1, j + 1);
        }
        else {
            return exchange(i, j, i, j + 1);
        }
    }

    public static void main(String[] args) {
        int[][] test = { { 1, 0, 2 }, { 3, 4, 5 }, { 8, 7, 6 } };
        Board testboard = new Board(test);
        StdOut.println(testboard.toString());
        Iterable<Board> testn = testboard.neighbors();
        /*for (Board s : testboard.neighbors()) {
            StdOut.println(s.toString());
        }*/
    }
}
