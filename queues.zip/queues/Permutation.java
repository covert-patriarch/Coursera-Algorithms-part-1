/* *****************************************************************************
 *  Name:              Alan Turing
 *  Coursera User ID:  123456
 *  Last modified:     1/1/2019
 **************************************************************************** */

import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;

public class Permutation {
    public static void main(String[] args) {
        //StdOut.println("1");
        int k = Integer.parseInt(args[0]);
        //StdOut.println(k);
        RandomizedQueue<String> rq = new RandomizedQueue<String>();
        //StdOut.println("2");
        //boolean p = StdIn.isEmpty();
        //StdOut.print(p);
        while (!StdIn.isEmpty()) {
            //StdOut.println("1");
            String s = StdIn.readString();
            rq.enqueue(s);
        }
        int ts = rq.size();
        for (int i = 1; i <= ts - k; i++) {
            String s = rq.dequeue();
        }
        for (String s : rq) {
            StdOut.println(s);
        }
    }
}
