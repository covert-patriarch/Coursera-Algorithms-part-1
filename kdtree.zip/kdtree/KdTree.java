import edu.princeton.cs.algs4.Point2D;
import edu.princeton.cs.algs4.RectHV;
import edu.princeton.cs.algs4.Stack;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

public class KdTree {
    private Stack<Node> tree;
    //private int size;
    private Node root;
    private Stack<Point2D> container;
    private RectHV searchrect;
    private Point2D nearestsofar;

    public KdTree() {
        tree = new Stack<Node>();
        //  size = 0;
        root = null;
    }

    public boolean isEmpty() {
        return tree.size() == 0;
    }

    private class Node implements Comparable<Node> {
        Point2D own;
        boolean parity;
        Node left, right;

        // parity == 1 means vertical; comparision based on x
        public Node(Point2D k, boolean horv) {
            own = k;
            parity = horv;
            left = null;
            right = null;
            nearestsofar = null;
        }

        public int compareTo(Node that) {
            this.parity = !that.parity;
            if (that.own.x() == this.own.x() && that.own.y() == this.own.y()) return 0;
            if (that.parity) {

                if (this.own.x() < that.own.x()) return -1;
                else return +1;
            }
            else {
                if (this.own.y() < that.own.y()) return -1;
                else return +1;
            }

        }
    }

    public int size() {
        return tree.size();
    }

    public void insert(Point2D p) {
        if (p == null) throw new IllegalArgumentException();
        Node one = new Node(p, true);
        root = put(root, one);

    }

    private Node put(Node x, Node test) {
        if (x == null) {
            tree.push(test);
            return test;
        }
        int cmp = test.compareTo(x);
        if (cmp < 0) {
            x.left = put(x.left, test);
        }
        else if (cmp > 0) {
            x.right = put(x.right, test);
        }
        return x;
    }

    private boolean search(Node x, Node test) {
        boolean p;
        if (x == null) p = false;
        else {
            int cmp = test.compareTo(x);
            if (cmp < 0) {
                p = search(x.left, test);
            }
            else if (cmp > 0) {
                p = search(x.right, test);
            }
            else {
                p = true;
            }
        }
        return p;

    }


    public boolean contains(Point2D p) {
        if (p == null) throw new IllegalArgumentException();
        Node one = new Node(p, true);
        return search(root, one);
    }

    public void draw() {

        for (Node s : tree) {
            StdDraw.setPenColor(StdDraw.BLACK);
            StdDraw.setPenRadius(0.01);
            s.own.draw();
            StdDraw.setPenRadius(0.001);
            if (s.parity) {
                StdDraw.setPenColor(StdDraw.RED);
                StdDraw.line(s.own.x(), 0, s.own.x(), 1);
            }
            else {
                StdDraw.setPenColor(StdDraw.BLUE);
                StdDraw.line(0, s.own.y(), 1, s.own.y());
            }
        }
    }

    private void rangesearch(Node x, RectHV noderect) {
        if (x == null) return;
        if (!searchrect.intersects(noderect)) return;
        if (searchrect.contains(x.own)) {
            container.push(x.own);
        }
        if (x.parity) {
            RectHV newrect = new RectHV(noderect.xmin(), noderect.ymin(), x.own.x(),
                                        noderect.ymax());
            rangesearch(x.left, newrect);
            newrect = new RectHV(x.own.x(), noderect.ymin(), noderect.xmax(), noderect.ymax());
            rangesearch(x.right, newrect);
        }
        else {
            RectHV newrect = new RectHV(noderect.xmin(), noderect.ymin(), noderect.xmax(),
                                        x.own.y());
            rangesearch(x.left, newrect);
            newrect = new RectHV(noderect.xmin(), x.own.y(), noderect.xmax(), noderect.ymax());
            rangesearch(x.right, newrect);
        }


    }

    public Iterable<Point2D> range(RectHV rect) {
        container = new Stack<Point2D>();
        searchrect = rect;
        RectHV test = new RectHV(0, 0, 1, 1);
        rangesearch(root, test);
        return container;

    }

    private void nearestsearch(Node x, RectHV noderect, Point2D p) {
        if (x == null) return;
        if (p.distanceSquaredTo(x.own) < p.distanceSquaredTo(nearestsofar)) {
            nearestsofar = x.own;
        }
        if (x.parity) {
            RectHV newrect = new RectHV(noderect.xmin(), noderect.ymin(), x.own.x(),
                                        noderect.ymax());
            if (newrect.distanceSquaredTo(p) < p.distanceSquaredTo(nearestsofar)) {
                nearestsearch(x.left, newrect, p);
            }
            newrect = new RectHV(x.own.x(), noderect.ymin(), noderect.xmax(), noderect.ymax());
            if (newrect.distanceSquaredTo(p) < p.distanceSquaredTo(nearestsofar)) {
                nearestsearch(x.right, newrect, p);
            }
        }
        else {
            RectHV newrect = new RectHV(noderect.xmin(), noderect.ymin(), noderect.xmax(),
                                        x.own.y());
            if (newrect.distanceSquaredTo(p) < p.distanceSquaredTo(nearestsofar)) {
                nearestsearch(x.left, newrect, p);
            }
            newrect = new RectHV(noderect.xmin(), x.own.y(), noderect.xmax(), noderect.ymax());
            if (newrect.distanceSquaredTo(p) < p.distanceSquaredTo(nearestsofar)) {
                nearestsearch(x.right, newrect, p);
            }
        }

    }

    public Point2D nearest(Point2D p) {
        nearestsofar = root.own;
        RectHV test = new RectHV(0, 0, 1, 1);
        nearestsearch(root, test, p);
        return nearestsofar;
    }

    public static void main(String[] args) {
        KdTree tester = new KdTree();
        Point2D p1 = new Point2D(0.1, 0.1);
        tester.insert(p1);
        Point2D p2 = new Point2D(0.5, 0.5);
        tester.insert(p2);
        Point2D p3 = new Point2D(0.25, 0.25);
        RectHV testrect = new RectHV(0.2, 0, 1, 1);
        Point2D p4 = new Point2D(0.1, 0.5);
        tester.insert(p3);
        tester.insert(p4);
        //StdOut.println(tester.contains(p1) + " " + tester.contains(p2) + " " + tester.contains(p3));
        //tester.draw();
        /*for (Point2D s : tester.range(testrect)) {
            StdOut.println(s.toString());
        }*/
        Point2D testpoint = new Point2D(0.5, 0.5001);
        StdOut.println(tester.nearest(testpoint).toString());
    }
}
