/* *****************************************************************************
 *  Name:              Alan Turing
 *  Coursera User ID:  123456
 *  Last modified:     1/1/2019
 **************************************************************************** */

import edu.princeton.cs.algs4.Point2D;
import edu.princeton.cs.algs4.RectHV;
import edu.princeton.cs.algs4.Stack;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

import java.util.TreeSet;

public class PointSET {
    private TreeSet<Point2D> tree;

    public PointSET() {
        tree = new TreeSet<Point2D>();
    }

    public boolean isEmpty() {
        return tree.size() == 0;
    }

    public int size() {
        return tree.size();
    }

    public void insert(Point2D p) {
        if (p == null) throw new IllegalArgumentException();
        tree.add(p);
    }

    public boolean contains(Point2D p) {
        if (p == null) throw new IllegalArgumentException();
        return tree.contains(p);
    }

    public void draw() {
        StdDraw.setPenColor(StdDraw.BLACK);
        StdDraw.setPenRadius(0.01);
        for (Point2D p : tree) {
            p.draw();
        }
    }

    public Iterable<Point2D> range(RectHV rect) {
        Stack<Point2D> inside = new Stack<Point2D>();
        for (Point2D p : tree) {
            if (rect.contains(p)) {
                inside.push(p);
            }
        }
        return inside;
    }

    public Point2D nearest(Point2D p) {
        if (tree.size() == 0) return null;
        double sdistance = Double.POSITIVE_INFINITY;
        Point2D ref = null;
        for (Point2D s : tree) {
            if (p.distanceSquaredTo(s) < sdistance) {
                sdistance = p.distanceSquaredTo(s);
                ref = s;
            }
        }
        return ref;
    }


    public static void main(String[] args) {
        PointSET tester = new PointSET();
        Point2D p = new Point2D(0.1, 0.1);
        tester.insert(p);
        p = new Point2D(0.5, 0.5);
        tester.insert(p);
        tester.draw();
        RectHV testrect = new RectHV(0.2, 0, 1, 1);
        for (Point2D s : tester.range(testrect)) {
            StdOut.println(s.toString());
        }
    }
}
