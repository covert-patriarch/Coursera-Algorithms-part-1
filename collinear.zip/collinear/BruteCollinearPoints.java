import edu.princeton.cs.algs4.StdOut;

import java.util.Arrays;

public class BruteCollinearPoints {
    private final Point[] ps;
    private int l, st;
    private final LineSegment[] list;

    public BruteCollinearPoints(Point[] points) {

        if (points == null) {

            throw new IllegalArgumentException();
        }
        l = points.length;
        //StdOut.println(l);

        for (int i = 0; i < l; i++) {
            if (points[i] == null) {

                throw new IllegalArgumentException();
            }
        }

        Arrays.sort(points);
        for (int i = 1; i < l; i++) {
            //StdOut.println(points[i].toString());
            String s1 = points[i - 1].toString();
            String s2 = points[i].toString();

            if (s1.equals(s2)) {

                throw new IllegalArgumentException();
            }
        }
        st = 0;
        ps = new Point[l];
        for (int i = 0; i < l; i++) {
            ps[i] = points[i];
        }


    }

    private boolean checker(Point p1, Point p2, Point p3, Point p4) {
        double s1 = p1.slopeTo(p2);
        double s2 = p1.slopeTo(p3);
        double s3 = p1.slopeTo(p4);
        return (s1 == s2 && s1 == s3);
    }

    public int numberOfSegments() {
        if (st != 0) return st;
        int n = 0;
        for (int i1 = 0; i1 < l; i1++) {
            for (int i2 = i1 + 1; i2 < l; i2++) {
                for (int i3 = i2 + 1; i3 < l; i3++) {
                    for (int i4 = i3 + 1; i4 < l; i4++) {
                        if (checker(ps[i1], ps[i2], ps[i3], ps[i4])) {
                            n++;
                        }
                    }
                }
            }
        }
        list = new LineSegment[n];
        st = n;
        return n;

    }

    public LineSegment[] segments() {
        if (st != 0) return list;
        int st = numberOfSegments();
        st = 0;
        for (int i1 = 0; i1 < l; i1++) {
            for (int i2 = i1 + 1; i2 < l; i2++) {
                for (int i3 = i2 + 1; i3 < l; i3++) {
                    for (int i4 = i3 + 1; i4 < l; i4++) {
                        if (checker(ps[i1], ps[i2], ps[i3], ps[i4])) {
                            list[st] = new LineSegment(ps[i1], ps[i4]);
                            st++;
                        }
                    }
                }
            }
        }
        //StdOut.println(n1);

        return list;
    }

    public static void main(String[] args) {
        Point[] test = new Point[4];
        test[0] = new Point(0, 0);
        test[1] = new Point(1, 1);
        test[2] = new Point(2, 2);
        test[3] = new Point(2, 2);
        BruteCollinearPoints s = new BruteCollinearPoints(test);
        LineSegment[] seg = s.segments();
        StdOut.println(seg[0].toString());
    }
}
