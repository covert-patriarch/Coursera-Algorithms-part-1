import edu.princeton.cs.algs4.MinPQ;
import edu.princeton.cs.algs4.Stack;
import edu.princeton.cs.algs4.StdOut;

public class Solver {
    private Board init, inittwin;
    private Node start, startwin, c, ct;
    private boolean solved, solvedtwin;
    private MinPQ<Node> ds, dstwin;
    private int totmoves;

    private class Node implements Comparable<Node> {
        public Node prev;
        public Board current;
        public int priority, moves;
        public boolean isgoal;

        public Node(Board b, Node mother, int mov) {
            current = b;
            prev = mother;
            moves = mov;
            priority = current.manhattan() + moves;
            isgoal = b.isGoal();
        }

        public int compareTo(Node that) {
            if (this.priority == that.priority) return 0;
            else if (this.priority < that.priority) return -1;
            else return 1;
        }
    }

    public Solver(Board initial) {
        if (initial == null) {
            throw new IllegalArgumentException();
        }
        init = initial;
        inittwin = initial.twin();
        start = new Node(init, null, 0);
        //StdOut.println(init.toString());
        startwin = new Node(inittwin, null, 0);
        //StdOut.println(inittwin.toString());
        ds = new MinPQ<Node>();
        dstwin = new MinPQ<Node>();
        ds.insert(start);
        dstwin.insert(startwin);
        c = ds.delMin();
        ct = dstwin.delMin();
        solved = c.current.isGoal();
        solvedtwin = ct.current.isGoal();
        //solvedtwin = false;
        //solved = isSolvable();
        totmoves = 0;

    }

    public boolean isSolvable() {

        while (!solved && !solvedtwin) {


            Iterable<Board> cneigh, ctneigh;
            cneigh = c.current.neighbors();
            ctneigh = ct.current.neighbors();
            for (Board s : cneigh) {
                if (c.prev == null) {
                    ds.insert(new Node(s, c, c.moves + 1));
                }
                else if (!s.equals(c.prev.current)) {
                    ds.insert(new Node(s, c, c.moves + 1));
                }
            }
            for (Board s : ctneigh) {
                if (ct.prev == null) {
                    dstwin.insert(new Node(s, ct, ct.moves + 1));
                }
                else if (!s.equals(ct.prev.current)) {
                    dstwin.insert(new Node(s, ct, ct.moves + 1));
                }
            }
            c = ds.delMin();
            ct = dstwin.delMin();
            solved = c.isgoal;
            solvedtwin = ct.isgoal;
        }
        totmoves = c.moves;
        return solved == true;
    }

    public int moves() {
        solved = isSolvable();
        if (solved) return totmoves;
        else return -1;
    }

    public Iterable<Board> solution() {
        solved = isSolvable();
        if (!solved) return null;
        else {
            Stack<Board> ans = new Stack<Board>();

            while (c.prev != null) {
                ans.push(c.current);
                c = c.prev;
            }
            Board[] revans = new Board[ans.size()];
            int i = ans.size() - 1;
            while (!ans.isEmpty()) {
                revans[i] = ans.pop();
                i--;
            }
            for (int j = 0; j < revans.length; j++) {
                ans.push(revans[j]);
            }
            ans.push(init);
            return ans;
        }
    }

    public static void main(String[] args) {
        int[][] test = { { 2, 0 }, { 1, 3 } };
        Board testboard = new Board(test);
        Solver hand = new Solver(testboard);
        //StdOut.println(hand.isSolvable());
        StdOut.println(hand.moves());
        for (Board s : hand.solution()) {
            StdOut.println(s.toString());
        }
    }
}
