/* *****************************************************************************
 *  Name:              Alan Turing
 *  Coursera User ID:  123456
 *  Last modified:     1/1/2019
 **************************************************************************** */

import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;

import java.util.Iterator;
import java.util.NoSuchElementException;


public class RandomizedQueue<Item> implements Iterable<Item> {
    private Item[] dq;
    private int capacity, size;
    private int first, last, rizer, psize;

    public RandomizedQueue() {
        size = 0;
        capacity = 16;
        first = -1;
        last = -1;
        rizer = 0;
        psize = -1;
        dq = (Item[]) new Object[capacity];
    }

    private void resize() {
        Item[] temp = (Item[]) new Object[2 * capacity];
        int n = 0;
        while (n != capacity) {
            temp[n] = dq[last];
            n++;
            last = last + 1;
            if (last == capacity) last = 0;
        }
        last = 0;
        first = capacity - 1;
        capacity *= 2;
        dq = temp;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public int size() {
        return size;
    }

    private Item removeFirst() {
        if (size == 0) {
            throw new NoSuchElementException();
        }
        else {
            size--;
            Item it = dq[first];
            dq[first] = null;
            if (size == 0) {
                first = -1;
                last = -1;
            }
            else {
                first = first - 1;
                if (first < 0) first = capacity - 1;
            }
            return it;
        }


    }

    public void enqueue(Item item) {
        if (item == null) {
            throw new IllegalArgumentException();
        }
        else {
            size++;
            if (size > capacity) {
                resize();
            }

            if (size == 1) {
                first = 0;
                last = 0;
                dq[first] = item;
            }
            else {
                first = (first + 1) % capacity;
                dq[first] = item;
            }

        }
    }

    public Item dequeue() {
        if (size == 0) {
            throw new NoSuchElementException();
        }
        else {
            Item it;
            int a = StdRandom.uniform(size);
            //StdOut.println(a + " " + first + " " + size);
            it = dq[(first - a) % capacity];
            dq[(first - a) % capacity] = dq[first];
            dq[first] = it;
            return removeFirst();
        }

    }

    public Item sample() {
        if (size == 0) {
            throw new NoSuchElementException();
        }
        else {
            int a = StdRandom.uniform(size);

            return dq[(last + a) % capacity];


        }
    }

    public Iterator<Item> iterator() {
        return new myriterator();
    }

    private class myriterator implements Iterator<Item> {
        private int[] permut;
        private int count;
        private Item current;

        public myriterator() {
            permut = StdRandom.permutation(size);
            count = 0;
            current = dq[(last + permut[count]) % capacity];
        }

        public boolean hasNext() {
            if (size == 0) return false;
            return (count <= size - 1);
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }

        public Item next() {
            // StdOut.println("next " + last + " " + count + " " + permut[count]);
            if (size == 0 || count > size - 1) {
                throw new NoSuchElementException();
            }


            count++;
            return dq[(last + permut[count - 1]) % capacity];
        }


    }

    public static void main(String[] args) {
        RandomizedQueue<Integer> rq = new RandomizedQueue<Integer>();
        
        for (Integer s : rq) {
            StdOut.println(s);
        }
    }
}
