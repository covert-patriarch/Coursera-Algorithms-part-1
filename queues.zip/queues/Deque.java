import java.util.Iterator;
import java.util.NoSuchElementException;

public class Deque<Item> implements Iterable<Item> {
    private Item[] dq;
    private int capacity, size;
    private int first, last;

    public Deque() {
        size = 0;
        capacity = 16;
        first = -1;
        last = -1;
        dq = (Item[]) new Object[capacity];

    }

    private void resize() {
        Item[] temp = (Item[]) new Object[2 * capacity];
        int n = 0;
        while (n != capacity) {
            temp[n] = dq[last];
            n++;
            last = last + 1;
            if (last == capacity) last = 0;
        }
        last = 0;
        first = capacity - 1;
        capacity *= 2;
        dq = temp;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public int size() {
        return size;
    }

    public void addFirst(Item item) {
        if (item == null) {
            throw new IllegalArgumentException();
        }
        else {
            size++;
            if (size > capacity) {
                resize();
            }

            if (size == 1) {
                first = 0;
                last = 0;
                dq[first] = item;
            }
            else {
                first = (first + 1) % capacity;
                dq[first] = item;
            }
        }
    }


    public void addLast(Item item) {
        if (item == null) {
            throw new IllegalArgumentException();
        }
        else {
            size++;
            if (size > capacity) {
                resize();
            }

            if (size == 1) {
                last = 0;
                first = 0;
                dq[last] = item;
            }
            else {
                last = last - 1;
                if (last < 0) last = capacity - 1;
                dq[last] = item;
            }

        }

    }

    public Item removeFirst() {
        if (size == 0) {
            throw new NoSuchElementException();
        }
        else {
            size--;
            Item it = dq[first];
            dq[first] = null;
            if (size == 0) {
                first = -1;
                last = -1;
            }
            else {
                first = first - 1;
                if (first < 0) first = capacity - 1;
            }
            return it;
        }


    }

    public Item removeLast() {
        if (size == 0) {
            throw new NoSuchElementException();
        }
        else {
            size--;
            Item it = dq[last];
            dq[last] = null;
            if (size == 0) {
                first = -1;
                last = -1;
            }
            else {
                last = last + 1;
                if (last == capacity) last = 0;
            }
            return it;

        }
    }


    public Iterator<Item> iterator() {
        //StdOut.println(4);
        return new myiterator();
    }

    private class myiterator implements Iterator<Item> {
        int itf = first;
        int count = 1;
        Item current;

        public myiterator() {
            if (size == 0) current = null;
            else current = dq[itf];
        }

        public boolean hasNext() {
            //StdOut.println("hasNext " + size + " " + count);
            if (size == 0) return false;

            return (count <= size);
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }

        public Item next() {
            //StdOut.println("next " + current);
            if (current == null) {
                throw new NoSuchElementException();
            }
            Item item = current;
            count++;
            itf = (itf - 1);
            if (itf < 0) itf = capacity - 1;
            current = dq[itf];
            // if (count == size + 1) current = null;
            return item;

        }


    }


    public static void main(String[] args) {
        Deque<Integer> q = new Deque<Integer>();
        for (Integer k : q) {
            System.out.println(k);
        }

    }
}
